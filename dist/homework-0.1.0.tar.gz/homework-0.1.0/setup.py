# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['homework']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['do_homework = homework.home:main']}

setup_kwargs = {
    'name': 'homework',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Зубайраева Ольга',
    'author_email': 'vadelevich2013@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
